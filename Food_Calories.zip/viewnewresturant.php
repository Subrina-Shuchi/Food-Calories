<option value="">Total Resturant List </option>
<?php
$con  = mysqli_connect("localhost","root","","food_db");
$s = mysqli_query($con,"select * from addnewresturant");

?>
<select>
<?php
while($r = mysqli_fetch_array($s))
{
	?>
	<option><?php echo $r['name'];?> </option>


<?php

}
 ?>
</select>

